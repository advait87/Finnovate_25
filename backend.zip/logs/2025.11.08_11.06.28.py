
# --- USER QUERY ---
# Give me sum of all the values in the amounts section
# --------------------

import pandas as pd
import warnings
import os
warnings.simplefilter(action='ignore', category=FutureWarning)
pd.options.display.float_format = '{:,.2f}'.format

try:
    # Use the full, escaped path to the Excel file
    data = pd.read_excel(r"trialbal.xlsx", header=2, usecols="A:G")
    
    # --- This is the code from Gemini (now correctly indented) ---
    print(data['Amount'].sum())
    # ----------------------------------------------------------

except FileNotFoundError:
    print("Error: Could not find shared data file 'trialbal.xlsx'.")
except Exception as e:
    print(f"An error occurred: {e}")
