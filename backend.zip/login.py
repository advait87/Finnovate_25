from flask import Flask, request, redirect, url_for, render_template, session

# Create a Flask application instance
app = Flask(__name__)

# A secret key is REQUIRED to use sessions securely
# CHANGE THIS to a long, random string!
app.config['SECRET_KEY'] = 'your-very-secret-random-key-here'

# This dictionary stores usernames and their corresponding passwords (and levels)
users = {
    "user1": {"password": "password1", "level": "level1"},
    "user2": {"password": "password2", "level": "level2"},
    "user3": {"password": "password3", "level": "level3"},
    "user4": {"password": "password4", "level": "level4"},
}

# Define a route for the login page
@app.route("/", methods=["GET", "POST"])
def login():
    error = None  # Initialize error message
    
    # This block handles the form submission
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        # Check credentials
        if username in users and users[username]["password"] == password:
            # SUCCESS: Store the user in the session
            session['username'] = username
            session['level'] = users[username]["level"]
            
            # Redirect to the user-specific page based on their level
            return redirect(url_for("user_page", username=username))
        else:
            # If no match, set the error message and re-render the login page
            error = "Invalid username or password"
            return render_template("login.html", error=error)

    # This block handles the GET request (just visiting the page)
    return render_template("login.html")

# This is the protected user page
@app.route("/<username>")
def user_page(username):
    # --- SECURITY CHECK ---
    if 'username' not in session or session['username'] != username:
        return redirect(url_for("login"))
    
    # --- Redirect based on the user's level ---
    user_level = session.get('level')
    if user_level == "level1":
        return redirect(url_for('level1'))
    elif user_level == "level2":
        return redirect(url_for('level2'))
    elif user_level == "level3":
        return redirect(url_for('level3'))
    elif user_level == "level4":
        return redirect(url_for('level4'))
    else:
        return "Unknown user level", 400

# Route for Level 1 users
@app.route("/level1")
def level1():
    return render_template("level1.html")

# Route for Level 2 users
@app.route("/level2")
def level2():
    return render_template("level2.html")

# Route for Level 3 users
@app.route("/level3")
def level3():
    return render_template("level3.html")

# Route for Level 4 users
@app.route("/level4")
def level4():
    return render_template("level4.html")

# (Optional) A route to log out
@app.route("/logout")
def logout():
    # Remove the username from the session
    session.pop('username', None)
    session.pop('level', None)
    return redirect(url_for("login"))

# Run the application
if __name__ == "__main__":
    app.run(debug=True)
