import pandas as pd
import json
from tqdm import tqdm
import os
import numpy as np
from flask_cors import CORS
from call_gemini import send_gemini_request_json
from send_email import gmail_create_and_send
import logging  # --- ADDED ---
from logging.handlers import RotatingFileHandler  # --- ADDED ---
import atexit
import datetime
import subprocess
import textwrap
from flask import Flask, jsonify, request, abort
import google.generativeai as genai

# --- ADDED: Setup Logging ---
if not os.path.exists('logs'):
    os.mkdir('logs')

# Define a consistent log format
log_formatter = logging.Formatter(
    '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
)

model = None
# --- File Handler ---
# Logs to 'logs/app.log', rotates files, keeps logs manageable
file_handler = RotatingFileHandler(
    'logs/app.log', maxBytes=10240, backupCount=10
)
file_handler.setFormatter(log_formatter)
file_handler.setLevel(logging.INFO)  # Log INFO and above to file

# --- Console Handler ---
# Logs to the console
console_handler = logging.StreamHandler()
console_handler.setFormatter(log_formatter)
console_handler.setLevel(logging.DEBUG)  # Log DEBUG and above to console

# --- Get Root Logger ---
# Configure the root logger. Flask's app.logger will inherit this.
root_logger = logging.getLogger()
root_logger.setLevel(logging.DEBUG)  # Set the lowest level to capture all
root_logger.addHandler(file_handler)
root_logger.addHandler(console_handler)

logging.info("Logging configured and application starting...")
# --- End Logging Setup ---


# Create a Flask app
app = Flask(__name__)
CORS(app)

# --- ADDED: Set Flask's logger level ---
# Ensure Flask's logger uses the handlers we set up
app.logger.setLevel(logging.DEBUG)


# Route to test the app
@app.route('/')
def home():
    logging.info("Test route '/' was hit")  # --- MODIFIED ---
    return "Hello, World!"

# Example API endpoint
@app.route("/send_anomaly_email", methods=["POST"])
def create_and_send_anomaly_email():
    app.logger.info("Request received for /send_anomaly_email") # --- ADDED ---
    # Get input data from the user (expected to be JSON)
    try:
        data = json.loads(request.data)
        gl = int(data.get("GL").strip())
        anomaly = data.get("Anomaly").strip()
        recipient = data.get("Email").strip()
    except Exception as e:
        app.logger.error(f"Error parsing request data in /send_anomaly_email: {e}") # --- ADDED ---
        return jsonify({"error": "Invalid JSON or data"}), 400
    print(f"Sending anomaly email for GL {gl} to {recipient}") # --- ADDED ---

    body = """
Hi,

There is an anomaly in your trialbal dataset. Please investigate and fix it. We observed that """

    if anomaly == "data unavailable":  # --- MODIFIED: Fix typo 'anamoly' -> 'anomaly' ---
        body += f"""your dataset is missing some data for this GL number {gl}. Please check your dataset and fix the issue.

Thank you,
Team ASCI
"""

    elif anomaly == "positive amount" or anomaly == "negative amount":
        body += f"you have the wrong value (possibly sign) for your GL number {gl}.\n"
        body += """Please check your dataset and fix the issue.

Thank you,
Team ASCI
"""

    elif anomaly == "range anomaly":
        body += "your numbers for this checkup are out of the normal range.\n"
        body += """If there's any explanation for this, please let us know. We will update the dataset accordingly.

Thank you,
Team ASCI
"""

    else:
        body += "an unexpected anomaly has been detected. Please review the dataset for any issues.\n"
        body += """If you need assistance, feel free to reach out.

Thank you,
Team ASCI
"""

    logging.info(f"Attempting to send email to {recipient} for GL {gl}")  # --- ADDED ---
    gmail_create_and_send(recipient=recipient, subject="Anomaly Detected", body=body)
    return "Email sent"

def is_range_anomaly(gl, n, df, amount):
    amounts = []
    
    # Scan through all Excel files in the "data" folder
    for entry in os.scandir("data"):
        if entry.is_file() and entry.name.endswith(".xlsx"):
            # Read the Excel file
            try:
                _df = pd.read_excel(entry.path)
                
                # Remove columns where the name starts with "Unnamed" (but preserve NaNs)
                _df = _df.loc[:, ~_df.columns.str.contains('^Unnamed', na=False)]
                
                # Check if the GL code exists in the file and append corresponding amounts
                matching_rows = _df[_df["GL"] == gl]
                amounts.extend(matching_rows["Amount"].tolist())
                
            except Exception as e:
                # --- MODIFIED ---
                logging.error(f"Error reading file {entry.name}: {e}")
    
    # If no matching amounts were found, return False (no anomaly)
    if not amounts:
        # --- MODIFIED ---
        logging.info(f"No matching historical amounts found for GL {gl}.")
        return False
    
    # Calculate the mean and standard deviation of the amounts
    mean_amount = np.mean(amounts)
    std_amount = np.std(amounts)
    
    # Check if the current amount is an anomaly (based on the specified range)
    if abs(amount - mean_amount) > n * std_amount:
        logging.warning(f"Range anomaly detected for GL {gl}. Amount: {amount}, Mean: {mean_amount}, StdDev: {std_amount}")  # --- ADDED ---
        return True
    
    return False
            

@app.route("/get_data", methods=["GET"])
def get_data():
    app.logger.info("Request received for /get_data")  # --- ADDED ---
    try:
        # Load the dataset while preserving the first two rows
        dataset = pd.read_excel("trialbal.xlsx", header=2)
        
        # Load the first two rows separately and keep them intact
        metadata = pd.read_excel("trialbal.xlsx", header=None, nrows=2)
    except FileNotFoundError:
        app.logger.error("trialbal.xlsx not found!") # --- ADDED ---
        return jsonify({"error": "Data file not found"}), 500
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500


    # Initialize a new column for anomalies
    if "Anomaly" not in dataset.columns:
        dataset["Anomaly"] = "Nothing"
    if "Email" not in dataset.columns:
        dataset["Email"] = ""
    if "Status" not in dataset.columns:
        dataset["Status"] = "Pending"
    ai = 0
    a = 0
    
    app.logger.info("Starting anomaly detection loop...") # --- ADDED ---
    # Loop through the rows of the dataset
    for i in tqdm(range(len(dataset))):
        # Check for missing values in critical columns
        dataset.at[i, "Email"] = f"advait.andhale@iitgn.ac.in" # --- MODIFIED: Use .at for setting value ---
        ai += 1
        for j in ["GL", "GL Name", "FS Grouping Main Head", "Amount"]:
            if pd.isna(dataset.at[i, j]) or dataset.at[i, j] == "":
                dataset.at[i, "Anomaly"] = "Data Unavailable"
                continue
        
        # Check for negative values in specific financial grouping columns
        if dataset.at[i, "FS Grouping Main Head"].lower().strip() in ["current assets", "non-current assets", "expenses", "tax expense"] and dataset.at[i, "Amount"] < 0:
            dataset.at[i, "Anomaly"] = "Negative Amount"
            continue
        
        # Check for positive values in specific financial grouping columns
        elif dataset.at[i, "FS Grouping Main Head"].lower().strip() in ["current liabilities", "non-current liabilities", "equity", "income"] and dataset.at[i, "Amount"] > 0:
            dataset.at[i, "Anomaly"] = "Positive Amount"
            continue

        # Check for range anomalies (this function will be discussed later)
        # if is_range_anomaly(dataset["GL"][i], 3, dataset, dataset["Amount"][i]):
            # if dataset["Anomaly"][i] == "Nothing":
                # dataset["Anomaly"][i] = "Range Anomaly"
            # else:
                # dataset["Anomaly"][i] += ", Range Anomaly"
            # a += 1
            # continue

    app.logger.info("Anomaly detection complete. Writing back to Excel...") # --- ADDED ---
    # Write the metadata back along with the modified dataset, ensuring the first 2 rows are preserved
    try:
        with pd.ExcelWriter("trialbal.xlsx", engine="xlsxwriter") as writer:
            # Write the first two metadata rows (these will be placed as is at the top)
            metadata.to_excel(writer, index=False, header=False, startrow=0)

            # Write the modified dataset starting from row 3 (index 2)
            dataset.to_excel(writer, index=False, header=True, startrow=2)
    except Exception as e:
        app.logger.error(f"Failed to write to trialbal.xlsx: {e}") # --- ADDED ---
        return jsonify({"error": f"Failed to write data file: {e}"}), 500
    
    app.logger.debug(f"Dataset columns: {dataset.columns}") # --- MODIFIED ---
    app.logger.info("/get_data request processed successfully.") # --- ADDED ---
    return dataset.to_json(orient="records")

@app.route("/get_distribution", methods=["GET"])
def get_distribution():
    app.logger.info("Request received for /get_distribution") # --- ADDED ---
    final_dict = {}
    try:
        dataset = pd.read_excel("trialbal.xlsx" )
        if "Anomaly" not in dataset.columns:
            dataset = pd.read_excel("trialbal.xlsx", header=2)
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx in /get_distribution: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500
        
    for entry in ["current assets", "non-current assets", "expenses", "tax expense", "current liabilities", "non-current liabilities", "equity", "income", "takover, ignore"]:
        final_dict[entry] = 0
    for i in range(len(dataset)):
        app.logger.debug(f"Checking anomaly: {dataset.at[i, 'Anomaly']}") # --- MODIFIED ---
        if dataset.at[i, "Anomaly"] != "Nothing":
            try:
                final_dict[dataset.at[i, "FS Grouping Main Head"].strip().lower()] += dataset.at[i, "Amount"]
            except KeyError:
                app.logger.warning(f"Unknown FS Grouping: {dataset.at[i, 'FS Grouping Main Head']}") # --- ADDED ---
    
    app.logger.info("/get_distribution request processed.") # --- ADDED ---
    return json.dumps(final_dict)


@app.route("/get_anomalies", methods=["GET"])
def get_anomalies():
    app.logger.info("Request received for /get_anomalies") # --- ADDED ---
    try:
        dataset = pd.read_excel("trialbal.xlsx")
        if "Anomaly" not in dataset.columns:
            dataset = pd.read_excel("trialbal.xlsx", header=2)
        if "Anomaly" not in dataset.columns:
            app.logger.warning("No 'Anomaly' column found in /get_anomalies") # --- ADDED ---
            return "No anomalies found"
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx in /get_anomalies: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500
        
    anomalies = {}

    for i in range(len(dataset)):
        if type(dataset.at[i, "Anomaly"]) == str:
            app.logger.debug(f"Found anomaly: {dataset.at[i, 'Anomaly']}") # --- MODIFIED ---
            anomaly_key = dataset.at[i, "Anomaly"].strip().lower() # --- MODIFIED ---
            if (anomaly_key not in anomalies):
                anomalies[anomaly_key] = 1
            else:
                anomalies[anomaly_key] += 1
                
    app.logger.info("/get_anomalies request processed.") # --- ADDED ---
    return json.dumps(anomalies)
# Run the app


@app.route("/api/send_anomaly_email/", methods=["GET"])
def send_anomaly_email():
    gl = request.args.get("gl")
    app.logger.info(f"Request received for /api/send_anomaly_email for GL: {gl}") # --- ADDED ---
    
    try:
        dataset = pd.read_excel("trialbal.xlsx", header=2)
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx in /api/send_anomaly_email: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500

    for i in range(len(dataset)):
        # --- MODIFIED: Added str() for robust comparison ---
        if str(dataset.at[i, "GL"]) == str(gl):
            if pd.isna(dataset.at[i, "Anomaly"]) or dataset.at[i, "Anomaly"] == "Nothing": # --- MODIFIED ---
                app.logger.warning(f"No anomaly found for GL {gl}, email not sent.") # --- ADDED ---
                return "{error: no anomaly}"
            else:
                try:
                    create_and_send_anomaly_email(dataset.at[i, "Email"], dataset.at[i, "Anomaly"], dataset.at[i, "GL"])
                    app.logger.info(f"Successfully sent anomaly email for GL {gl} to {dataset.at[i, 'Email']}") # --- ADDED ---
                    return "{success: email sent}"
                except Exception as e: # --- MODIFIED ---
                    app.logger.error(f"Failed to send email for GL {gl}: {e}") # --- MODIFIED ---
                    return "{error: email not sent}"
                    
    app.logger.warning(f"GL {gl} not found in /api/send_anomaly_email") # --- ADDED ---
    return "{error: no such gl}"

@app.route("/api/send_automated_email", methods=["POST"])
async def send_automated_email():
    app.logger.info("Request received for /api/send_automated_email") # --- ADDED ---
    try:
        data = json.loads(request.data)
        recipient = data["recipient"].strip()
        prompt = data["prompt"]
    except Exception as e:
        app.logger.error(f"Error parsing request data: {e}") # --- ADDED ---
        return jsonify({"error": "Invalid JSON"}), 400
        
    app.logger.info(f"Sending Gemini request for recipient: {recipient}") # --- ADDED ---
    gemini_response = send_gemini_request_json(prompt)
    app.logger.debug(f"Gemini response: {gemini_response}") # --- MODIFIED ---
    
    if "error" in gemini_response:
        app.logger.error(f"Error from Gemini API: {gemini_response}") # --- ADDED ---
        return "Error"
    else:
        try:
            gmail_create_and_send(recipient=recipient, subject="Issue found on GL analysis", body=gemini_response)
            app.logger.info(f"Successfully sent automated email to {recipient}") # --- ADDED ---
            return "Email sent"
        except Exception as e:
            app.logger.error(f"Failed to send automated email to {recipient}: {e}") # --- ADDED ---
            return "Error sending email"

@app.route("/set_status", methods=["POST"])
def set_status():
    app.logger.info("Request received for /set_status") # --- ADDED ---
    # Get input data from the user (expected to be JSON)
    try:
        data = json.loads(request.data)
        # Extract the GL, status, and optional amount
        gl_code = int(data.get("GL").strip())
        status = data.get("Status").strip()
    except Exception as e:
        app.logger.error(f"Error parsing request data in /set_status: {e}") # --- ADDED ---
        return jsonify({"error": "Invalid JSON or data"}), 400
    
    # Validate input data
    if not gl_code or not status:
        app.logger.warning("Bad request to /set_status: GL or Status missing") # --- ADDED ---
        return jsonify({"error": "GL and Status must be provided"}), 400

    try:
        # Load the dataset and preserve metadata
        dataset = pd.read_excel("trialbal.xlsx", header=2)
        # Preserve first two rows (metadata) for later writing
        metadata = pd.read_excel("trialbal.xlsx", header=None, nrows=2)
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx in /set_status: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500
    
    # Check if the GL code exists in the dataset
    if gl_code not in dataset["GL"].values:
        app.logger.warning(f"GL code {gl_code} not found in /set_status") # --- ADDED ---
        return jsonify({"error": f"GL code {gl_code} not found in the dataset."}), 404
    
    # Apply the status to the specified GL code
    updated_rows = dataset[dataset["GL"] == gl_code]
    
    if updated_rows.empty:
        # This check is redundant due to the 'in' check above, but good for safety
        app.logger.error(f"Logic error: GL {gl_code} found but updated_rows is empty.") # --- ADDED ---
        return jsonify({"error": f"No rows found with GL code {gl_code}."}), 404
    
    # Update the status for all rows with the specified GL code
    for index, row in updated_rows.iterrows():
        dataset.at[index, "Status"] = status # --- MODIFIED: Use .at ---
        app.logger.info(f"Applied '{status}' status to GL code {gl_code} at row {index}") # --- MODIFIED ---

    # Write the updated dataset back to the Excel file, preserving the metadata
    try:
        with pd.ExcelWriter("trialbal.xlsx", engine="xlsxwriter") as writer:
            # Write the first two metadata rows
            metadata.to_excel(writer, index=False, header=False, startrow=0)
            
            # Write the updated dataset starting from row 3 (index 2)
            dataset.to_excel(writer, index=False, header=True, startrow=2)
    except Exception as e:
        app.logger.error(f"Failed to write to trialbal.xlsx in /set_status: {e}") # --- ADDED ---
        return jsonify({"error": f"Failed to write data file: {e}"}), 500
        
    return jsonify({"message": f"Status '{status}' successfully applied to GL code {gl_code}."}), 200



@app.route("/set_anomaly", methods=["POST"])
def set_anomaly():
    app.logger.info("Request received for /set_anomaly") # --- ADDED ---
    # Get input data from the user (expected to be JSON)
    try:
        data = json.loads(request.data)
        # Extract the GL, anomaly type, and optional amount
        gl_code = int(data.get("GL").strip())
        anomaly_type = data.get("Anomaly").strip()
    except Exception as e:
        app.logger.error(f"Error parsing request data in /set_anomaly: {e}") # --- ADDED ---
        return jsonify({"error": "Invalid JSON or data"}), 400
        
    # Validate input data
    if not gl_code or not anomaly_type:
        app.logger.warning("Bad request to /set_anomaly: GL or Anomaly missing") # --- ADDED ---
        return jsonify({"error": "GL and Anomaly type must be provided"}), 400

    try:
        # Load the dataset and preserve metadata
        dataset = pd.read_excel("trialbal.xlsx", header=2)
        # Preserve first two rows (metadata) for later writing
        metadata = pd.read_excel("trialbal.xlsx", header=None, nrows=2)
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx in /set_anomaly: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500
    
    # Check if the GL code exists in the dataset
    if gl_code not in dataset["GL"].values:
        app.logger.warning(f"GL code {gl_code} not found in /set_anomaly") # --- ADDED ---
        return jsonify({"error": f"GL code {gl_code} not found in the dataset."}), 404
    
    # Apply the anomaly to the specified GL code
    updated_rows = dataset[dataset["GL"] == gl_code]
    
    if updated_rows.empty:
        app.logger.error(f"Logic error: GL {gl_code} found but updated_rows is empty.") # --- ADDED ---
        return jsonify({"error": f"No rows found with GL code {gl_code}."}), 404

    # Update the anomaly for all rows with the specified GL code
    for index, row in updated_rows.iterrows():
        dataset.at[index, "Anomaly"] = anomaly_type # --- MODIFIED: Use .at ---
        app.logger.info(f"Applied '{anomaly_type}' anomaly to GL code {gl_code} at row {index}") # --- MODIFIED ---
    
    # Write the updated dataset back to the Excel file, preserving the metadata
    try:
        with pd.ExcelWriter("trialbal.xlsx", engine="xlsxwriter") as writer:
            # Write the first two metadata rows
            metadata.to_excel(writer, index=False, header=False, startrow=0)
            
            # Write the updated dataset starting from row 3 (index 2)
            dataset.to_excel(writer, index=False, header=True, startrow=2)
    except Exception as e:
        app.logger.error(f"Failed to write to trialbal.xlsx in /set_anomaly: {e}") # --- ADDED ---
        return jsonify({"error": f"Failed to write data file: {e}"}), 500
        
    return jsonify({"message": f"Anomaly '{anomaly_type}' successfully applied to GL code {gl_code}."}), 200


@app.route("/number_of_anomalies", methods=["GET"])
def number_of_anomalies():
    app.logger.info("Request received for /number_of_anomalies") # --- ADDED ---
    try:
        dataset = pd.read_excel("trialbal.xlsx", header=2)
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx in /number_of_anomalies: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500
        
    anomalies = len(dataset[dataset["Anomaly"] != "Nothing"])
    return str(anomalies)

@app.route("/number_of_total_rows", methods=["GET"])
def number_of_total_rows():
    app.logger.info("Request received for /number_of_total_rows") # --- ADDED ---
    try:
        dataset = pd.read_excel("trialbal.xlsx", header=2)
    except Exception as e:
        app.logger.error(f"Error reading trialbal.xlsx in /number_of_total_rows: {e}") # --- ADDED ---
        return jsonify({"error": f"Error reading data file: {e}"}), 500
        
    total_rows = len(dataset)
    return str(total_rows)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
except KeyError:
    print("Error: GEMINI_API_KEY environment variable not set.")

    GEMINI_API_KEY = "AIzaSyB72GRtOrbyZBzhxkt1ALk-KPbhoIVKnx8" 
    
   
    model = None

EXCEL_FILE = "trialbal.xlsx"
DATA_COLUMNS = "[GL, GL Name, Gr GL, Gr GL Name, Amount, FS Grouping Main Head, FS Grouping Main Sub Head]"
TEMP_FILE_DIR = os.path.join(SCRIPT_DIR, "Logs")
HARDCODED_HEADER = 2
HARDCODED_USECOLS = "A:G"

# This is the "brain" of the AI
# (Near line 31)
# This is the "brain" of the AI
# This is the "brain" of the AI
# This is the "brain" of the AI
# This is the "brain" of the AI
SYSTEM_PROMPT = f"""
You are an expert Python Pandas code assistant.
A pandas DataFrame named data has already been loaded from the Excel file '{os.path.basename(EXCEL_FILE)}' using pd.read_excel(..., header={HARDCODED_HEADER}, usecols="{HARDCODED_USECOLS}").

The DataFrame has the following columns:
{DATA_COLUMNS}

---
Here are some examples of the data in each column to help you verify:
•⁠  ⁠GL: [11100110, 11100200, 11100400, 11200010]
•⁠  ⁠GL Name: ["Inventory-Raw Material-Domestic", "Capital Inventory-Domestic", "Inventory-Stores & Spares-Domestic", "Business Partner-Loan"]
•⁠  ⁠FS Grouping Main Head: ["Non-Current Assets", "Current Assets", "Current Liabilities", "Income", "Equity"]
•⁠  ⁠FS Grouping Main Sub Head: ["Capital work-in-progress", "Inventories", "Financial Liabilities - Other financial liabil..."]
---

## Anomaly Detection Task
If the user asks to "find anomalies", "check data", or "validate data", you MUST generate code to perform the following steps:
1.  Import numpy as np.
2.  Standardize missing data: data.replace("", np.nan, inplace=True)
3.  Create a new column: data['Anomaly'] = 'None'
4.  Rule 1 (Missing Data): Check all columns. If any cell in a row is null (.isnull().any(axis=1)), set 'Anomaly' to 'Data Unavailable'.
5.  Rule 2 (Financial Rules): For rows where 'Anomaly' is still 'None':
    * Create a normalized column: clean_fs_head = data['FS Grouping Main Head'].astype(str).str.strip().str.lower()
    * Define: negative_categories = ["current assets", "non-current assets", "expenses", "tax expense"]
    * Define: positive_categories = ["current liability", "non-current liability", "equity", "income"]
    * Negative Anomaly: Set 'Anomaly' to 'Negative Amount' if Amount < 0 AND clean_fs_head is in negative_categories.
    * Positive Anomaly: Set 'Anomaly' to 'Positive Amount' if Amount > 0 AND clean_fs_head is in positive_categories.
6.  Final Output: After applying all rules, print the data rows that have an anomaly: print(data[data['Anomaly'] != 'None'])

---
Your task is to generate ONLY the single block of Python code needed to answer the user's question.
•⁠  ⁠The code MUST include a print() statement to display the final result.

RULES:
1.  CONTEXT AWARENESS: You MUST use the data examples above to decide which column to filter.
2.  SINGLE VALUE: If the result is a single value, use .values[0] or .iloc[0] to print only the value.
3.  ROBUST TEXT FILTERING: When filtering on text columns (like in Example 2), you must normalize the text.
4.  FULL DATAFRAME: If the result is multiple rows, print the full DataFrame.
5.  NO MARKDOWN: Do NOT include markdown (like python) or any explanation.
6.  *NO LOAD CODE:* Do NOT include the code to load the data; it is already loaded as ⁠ data ⁠.

---
Example Request 1 (Single Value):
what is the amount of gl 11100110

Example Response 1:
print(data[data['GL'] == 11100110]['Amount'].values[0])

Example Request 2 (Context + Robust Filter):
show me all current assets

Example Response 2:
clean_data = data['FS Grouping Main Head'].str.replace(r'\s+', ' ', regex=True).str.strip().str.lower()
print(data[clean_data == 'current assets'])

Example Request 3 (NEW - Anomaly Task):
find all anomalies

Example Response 3:
import numpy as np
data.replace("", np.nan, inplace=True)
data['Anomaly'] = 'None'
missing_mask = data.isnull().any(axis=1)
data.loc[missing_mask, 'Anomaly'] = 'Data Unavailable'
clean_fs_head = data['FS Grouping Main Head'].astype(str).str.strip().str.lower()
negative_categories = ["current assets", "non-current assets", "expenses", "tax expense"]
positive_categories = ["current liability", "non-current liability", "equity", "income"]
negative_mask = clean_fs_head.isin(negative_categories) & (data['Amount'] < 0) & (data['Anomaly'] == 'None')
positive_mask = clean_fs_head.isin(positive_categories) & (data['Amount'] > 0) & (data['Anomaly'] == 'None')
data.loc[negative_mask, 'Anomaly'] = 'Negative Amount'
data.loc[positive_mask, 'Anomaly'] = 'Positive Amount'
print(data[data['Anomaly'] != 'None'])
"""
# --- 2. Initialize Flask, AI Model, and Load Data ---
def setup_server():
    """
    This function runs once before the server starts.
    It checks if the Excel file exists and sets up the AI.
    """
    global model
    print("Server starting up...")
    
    # Configure Gemini
    try:
        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel('gemini-2.5-flash')
        model.generate_content("test")
        print("Gemini model configured and tested.")
    except Exception as e:
        print(f"FATAL ERROR: Could not configure Gemini: {e}")
        exit()

    # Load and cache data
    try:
        # We just check if the file exists. We don't load it here.
        if not os.path.exists(EXCEL_FILE):
            raise FileNotFoundError(f"File not found: {EXCEL_FILE}")
        
        print(f"Verified that data file '{EXCEL_FILE}' exists.")

    except FileNotFoundError:
        print(f"FATAL ERROR: Could not find the file {EXCEL_FILE}")
        exit()
    except Exception as e:
        print(f"FATAL ERROR: Error checking data file: {e}")
        exit()
    try:
        if not os.path.exists(TEMP_FILE_DIR):
            os.makedirs(TEMP_FILE_DIR)
            print(f"Created query log directory: {TEMP_FILE_DIR}")
        else:
            print(f"Query log directory found: {TEMP_FILE_DIR}")
    except Exception as e:
        print(f"FATAL ERROR: Could not create directory {TEMP_FILE_DIR}: {e}")
        exit()
    
    
        
    @app.teardown_appcontext
    def cleanup(exception=None):
        pass

    # Register cleanup function to run on exit
    @app.teardown_appcontext
    def cleanup(exception=None):
        pass # Using 'atexit' is more reliable for file cleanup


def cleanup_cache():
    """Runs when the server is stopped (e.g., Ctrl+C)."""
    print("\nServer shutting down. Goodbye!")
    
atexit.register(cleanup_cache)
# --- 3. Helper Functions (Your original logic) ---

def get_gemini_code(user_query: str) -> str:
    """Sends the query to Gemini and returns the code string."""
    if not model:
        raise Exception("Gemini model is not initialized.")
    try:
        full_prompt = SYSTEM_PROMPT + "\nUser Request:\n" + user_query
        response = model.generate_content(full_prompt)
        
        code = response.text.strip()
        code = code.replace("python", "").replace("```", "").strip()
        return code
        
    except Exception as e:
        print(f"Error communicating with Gemini: {e}")
        return ""

def execute_code(code: str, user_query: str) -> tuple[str, str]:
    """Wraps code, saves to a timestamped file, and runs it."""
    
    indented_code = textwrap.indent(code, '    ')

    excel_file_path_for_script = EXCEL_FILE.replace("\\", "\\\\")

    script_content = f"""
# --- USER QUERY ---
# {user_query}
# --------------------

import pandas as pd
import warnings
import os
warnings.simplefilter(action='ignore', category=FutureWarning)
pd.options.display.float_format = '{{:,.2f}}'.format

try:
    # Use the full, escaped path to the Excel file
    data = pd.read_excel(r"{excel_file_path_for_script}", header=2, usecols="A:G")
    
    # --- This is the code from Gemini (now correctly indented) ---
{indented_code}
    # ----------------------------------------------------------

except FileNotFoundError:
    print("Error: Could not find shared data file '{EXCEL_FILE}'.")
except Exception as e:
    print(f"An error occurred: {{e}}")
"""
    
    now = datetime.datetime.now()
    
    short_filename = now.strftime("%Y.%m.%d_%H.%M.%S.py")
    
    temp_file_name = os.path.join(TEMP_FILE_DIR, short_filename)
        
    try:
        with open(temp_file_name, 'w', encoding='utf-8') as f:
            f.write(script_content)
        
        print(f"Running temp file: {temp_file_name}")

        result = subprocess.run(
            ['python', temp_file_name],
            capture_output=True,
            text=True,
            timeout=10,
            encoding='utf-8'
        )
        
        return result.stdout, result.stderr
        
    finally:
        # We are keeping the temp .py files for logging
        pass
# --- 4. API Endpoint ---

@app.route("/query", methods=["GET", "POST","OPTIONS"])  # <-- Now accepts GET and POST
def handle_query():
    print("LK")
    """
    The main API endpoint. Takes a natural language query
    and returns the result from the DataFrame.
    """
    user_query = None
    
    if request.method == "POST":
        data = request.get_json()
        if not data or 'query' not in data:
            abort(400, description="Invalid POST: JSON body with 'query' key is required.")
        user_query = data['query']

    # Original code snippet (Lines 319-325)
    elif request.method == "OPTIONS":
    # Preflight request — just acknowledge it
        return jsonify({"message": "CORS preflight OK"}), 200

        
         
    elif request.method == "GET":
        user_query = request.args.get("query")
        if not user_query:
            abort(400, description="Invalid GET: URL parameter 'query' is required. (e.g., /query?query=your question)")

    if not user_query:
        abort(400, description="Invalid request: 'query' cannot be empty.")
        
    try:
        generated_code = get_gemini_code(user_query)
        if not generated_code:
            return jsonify({"error": "Gemini failed to generate code."}), 500

        stdout, stderr = execute_code(generated_code, user_query)

        if stderr:
            return jsonify({"error": stderr}), 500
        else:
            return jsonify({"response": stdout.strip()}), 200

    except Exception as e:
        return jsonify({"error": f"An internal server error occurred: {str(e)}"}), 500


    
if __name__ == '__main__':
    setup_server() # Run the setup
    logging.info("Starting Flask app on 0.0.0.0:4444") # --- MODIFIED ---
    app.run(host="0.0.0.0", port=4444)
