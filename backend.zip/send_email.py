import base64
import os
import mimetypes
from email.message import EmailMessage
from googleapiclient.errors import HttpError
from gmail_auth import get_gmail_service  # Import your auth function

def gmail_create_and_send(sender=None,recipient=None,subject=None,body=None,file_path=None):
    """
    Creates a draft email and sends it immediately.
    If file_path is provided and valid, it attaches the file.
    If file_path is None, it sends a plain text email.
    """
    # 1. Get the authenticated service
    service = get_gmail_service()

    # 2. Create the EmailMessage object
    message = EmailMessage()
    
    # --- UPDATE THESE ---
    message["To"] = recipient
    message["From"] = sender

    # 3. --- Handle attachment (if any) ---
    if file_path:
        # A file path is provided, try to attach it
        if not os.path.exists(file_path):
            print(f"Error: File not found at {file_path}. Sending email without it.")
            message.set_content(body)
            message["Subject"] = subject
        else:
            print(f"Attaching file: {file_path}")
            message.set_content(body)
            message["Subject"] = subject

            # Guess the MIME type
            mime_type, _ = mimetypes.guess_type(file_path)
            if mime_type is None:
                mime_type = 'application/octet-stream'
            
            main_type, sub_type = mime_type.split('/', 1)

            # Read and attach the file
            with open(file_path, 'rb') as f:
                message.add_attachment(f.read(),
                                       maintype=main_type,
                                       subtype=sub_type,
                                       filename=os.path.basename(file_path))
    else:
        # No file path provided, send a simple email
        print("No attachment path provided. Sending a plain text email.")
        message.set_content(body)
        message["Subject"] = subject

    # 4. Encode the message
    encoded_message = base64.urlsafe_b64encode(message.as_bytes()).decode()

    # 5. Create the draft body
    create_message = {"message": {"raw": encoded_message}}

    # 6. Call the API to CREATE the draft
    draft = (
        service.users()
        .drafts()
        .create(userId="me", body=create_message)
        .execute()
    )

    draft_id = draft['id']
    print(f'Draft created successfully. Draft id: {draft_id}')

    # 7. --- AUTOMATICALLY SEND THE DRAFT ---
    print(f'Now sending draft...')
    
    send_body = {'id': draft_id}

    sent_message = (
        service.users()
        .drafts()
        .send(userId='me', body=send_body)
        .execute()
    )
    
    print(f'Draft sent successfully. Message Id: {sent_message["id"]}')

