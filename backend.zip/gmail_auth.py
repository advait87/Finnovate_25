import os.path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# --- THIS IS THE KEY CHANGE ---
# We need scopes that allow sending and drafting, not just reading.
SCOPES = [
    "https://www.googleapis.com/auth/gmail.compose",
    "https://www.googleapis.com/auth/gmail.readonly" # Good to keep for listing
]

def get_gmail_service():
    """Authenticates the user and returns the Gmail API service client."""
    creds = None
    # The file token.json stores the user's access and refresh tokens.
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            # Use your credentials file
            flow = InstalledAppFlow.from_client_secrets_file(
                "advait-level1credentials.json", SCOPES
            )
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open("token.json", "w") as token:
            token.write(creds.to_json())

    # Build and return the service
    try:
        service = build("gmail", "v1", credentials=creds)
        return service
    except Exception as e:
        print(f"An error occurred building the service: {e}")
        return None
