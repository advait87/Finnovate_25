from google import genai
import json
def send_gemini_request_json(prompt):
    client = genai.Client()
    response = client.models.generate_content(
        model="gemini-2.5-flash-lite",
        contents=f"Write an email body for the following prompt. I will be using this in an agent, so don't format anything. Don't write a template email, don't leave fields to be inserted afterwards. Prompt:.{prompt}. ",
    )
    try: 
        response_text = response.text
        # response_text.replace("'", "\"")
        # response_text.replace("'", "\"")
        json_response = response_text
        print(json_response)
        return json_response
    except Exception as e:
        print(response.text)
        raise e

