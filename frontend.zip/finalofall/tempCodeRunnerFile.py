

# --- NEW: Helper function to fetch API data with timeout ---
def fetch_api_data(url, timeout=1):
    """Fetches data from an API, returns (data, error) tuple."""
    try:
        response = requests.get(url, timeout=timeout)
        response.raise_for_status() # Raise error for 4xx/5xx
        return response.json(), None
    except requests.exceptions.RequestException as e:
        return None, str(e)
    except json.JSONDecodeError:
        return None, "Error decoding JSON response from server."


# --- Login Route ---
@app.route("/", methods=["GET", "POST"])