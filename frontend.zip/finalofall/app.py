from flask import Flask, request, redirect, url_for, render_template, session, jsonify
import json
import os
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-very-secret-random-key-here'

# --- API URLs ---
API_BASE_URL = "http://10.7.53.37:4444"
API_DATA_URL = f"{API_BASE_URL}/get_data"
API_ANOMALIES_URL = f"{API_BASE_URL}/get_anomalies"
API_DISTRIBUTION_URL = f"{API_BASE_URL}/get_distribution"

# --- Helper functions ---
def fetch_api_data(url, timeout=1):
    """Fetches data from API, returns (data, error)"""
    try:
        response = requests.get(url, timeout=timeout)
        response.raise_for_status()
        return response.json(), None
    except requests.exceptions.RequestException as e:
        return None, str(e)
    except json.JSONDecodeError:
        return None, "Error decoding JSON response."

# --- Login Route ---
@app.route("/", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username")
        session['username'] = username

        if username == 'user1':
            return redirect(url_for('level1'))
        elif username == 'user2':
            return redirect(url_for('level2'))
        elif username == 'user3':
            return redirect(url_for('level3'))
        else:
            if username:
                return redirect(url_for('level1'))
        error = "Please enter a username"
    return render_template("login.html", error=error)

# --- Level 1 Page ---
@app.route("/level1")
def level1():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template("level1.html")

# --- Level 2 Page ---
@app.route("/level2")
def level2():
    if 'username' not in session:
        return redirect(url_for('login'))

    data, error = fetch_api_data(API_DATA_URL, timeout=1)
    if error:
        print(f"API Error level2: {error}")
        data = [
            {"gl_name": "Inventory-Raw", "email": "mock1@example.com", "gl": "11100110",
             "fs_grouping_main_sub_head": "Inventory", "gr_gl": "2021001001", "gr_gl_name": "Inventory",
             "amount": "15000.00", "submitted_by": "user1"},
            {"gl_name": "Inventory-Finished", "email": "mock2@test.com", "gl": "11100112",
             "fs_grouping_main_sub_head": "Inventory", "gr_gl": "2021001002", "gr_gl_name": "Inventory",
             "amount": "125000.50", "submitted_by": "user1"},
            {"gl_name": "Sales-Domestic", "email": "mock3@demo.com", "gl": "41100100",
             "fs_grouping_main_sub_head": "Revenue", "gr_gl": "4000000000", "gr_gl_name": "Revenue",
             "amount": "8500.75", "submitted_by": "user1"}
        ]
        error = "API Error. Showing mock data."

    return render_template("level2.html", data=data, error=error)

# --- Level 3 Page ---
@app.route("/level3")
def level3():
    if 'username' not in session:
        return redirect(url_for('login'))

    data, error = fetch_api_data(API_DATA_URL, timeout=1)
    if error:
        print(f"API Error level3: {error}")
        data = [
            {"gl_name": "Sales-Domestic", "email": "mock3@demo.com", "gl": "41100100",
             "fs_grouping_main_sub_head": "Revenue", "gr_gl": "4000000000", "gr_gl_name": "Revenue",
             "amount": "8500.75", "submitted_by": "user3"}
        ]
        error = "API Error. Showing mock data."

    return render_template("level3.html", data=data, error=error)

# --- Dashboard ---
@app.route("/dashboard")
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template("dashboard.html")

    api_errors = []

    # Total GL Entries
    all_data, err = fetch_api_data(API_DATA_URL)
    total_gl = len(all_data) if isinstance(all_data, list) else 0
    if err:
        api_errors.append(f"Could not load Total GL Entries: {err}")

    # Total Anomalies
    anomalies_data, err = fetch_api_data(API_ANOMALIES_URL)
    total_anomalies = len(anomalies_data) if isinstance(anomalies_data, list) else 0
    if err:
        api_errors.append(f"Could not load Total Anomalies: {err}")

    # Chart Data
    chart_data, err = fetch_api_data(API_DISTRIBUTION_URL)
    if err or not chart_data:
        api_errors.append(f"Could not load chart data: {err}. Using mock charts.")
        chart_data = {
            "line_chart": {
                "labels": ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
                "datasets": [
                    {"label": "Actual (Mock)", "data": [120, 150, 130, 170, 160, 190], "borderColor": "#4f46e5", "backgroundColor": "#4f46e5", "tension": 0.3},
                    {"label": "Budgeted (Mock)", "data": [130, 140, 140, 160, 160, 180], "borderColor": "#06b6d4", "backgroundColor": "#06b6d4", "borderDash": [5, 5], "tension": 0.3}
                ]
            },
            "pie_chart": {
                "labels": ['Duplicate Entry', 'Amount Mismatch', 'Policy Violation', 'Other'],
                "data": [40, 25, 15, 7]
            },
            "bar_chart": {
                "labels": ['Current Assets', 'Non-Current Assets', 'Equity', 'Current Liabilities', 'Non-Current Liabilities'],
                "datasets": [{"label": "Total Amount (in k)", "data": [580, 720, 310, 450, 210]}]
            }
        }

    return render_template("dashboard.html",
                           total_gl=total_gl,
                           total_anomalies=total_anomalies,
                           chart_data_json=json.dumps(chart_data),
                           api_errors=api_errors)

# --- Logout ---
@app.route("/logout")
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))




# --- Submit Data ---
@app.route("/submit_data", methods=["POST"])
def submit_data():
    if 'username' not in session:
        return jsonify({"error": "Unauthorized"}), 401

    new_entry = {
        "gl_name": request.form.get('gl_name'),
        "email": request.form.get('email'),
        "gl": request.form.get('gl'),
        "fs_grouping_main_sub_head": request.form.get('fs_grouping_main_sub_head'),
        "gr_gl": request.form.get('gr_gl'),
        "gr_gl_name": request.form.get('gr_gl_name'),
        "amount": request.form.get('amount'),
        "submitted_by": session.get('username')
    }

    try:
        requests.post(API_DATA_URL, json=new_entry, timeout=1)
    except requests.exceptions.RequestException as e:
        print(f"WARNING: Failed to POST data to API: {e}")

    return redirect(url_for('level1'))

# --- Run App ---
if __name__ == "__main__":
    app.run(debug=True)
